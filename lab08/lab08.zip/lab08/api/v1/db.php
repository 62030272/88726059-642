<?php
$DBServer = 'database';
$DBUser   = 'root';
$DBPass   = 'tiger';
$DBName   = 'testdb';
$conn = new mysqli($DBServer, $DBUser, $DBPass, $DBName);
$sql = '';